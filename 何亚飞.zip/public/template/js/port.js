var socket_local_port='http://localhost:3000';
var socket_http_port='http://139.196.137.117 ';
var socket_https_port='https://www.oaimin.cn:443';
var port = socket_http_port;