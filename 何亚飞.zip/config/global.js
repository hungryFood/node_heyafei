module.exports = {
    page_num:3,//默认页数
    page_start:1,//默认起始页
    rule:"",//排序规则
    q:"",//搜索关键字`
    upload:{
       product:'/upload/product/',
       user:'/upload/user/',
       banner:'/upload/banner/'
    }
}